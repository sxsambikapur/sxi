/* =========================================
   ST. XAVIER'S WEBSITE - INTERACTIVITY
   ========================================= */

// 1. PRELOADER
// Waits for the entire page (images & styles) to load before hiding the loader
window.addEventListener('load', () => {
    const preloader = document.getElementById('preloader');
    
    // Start fade out
    preloader.style.opacity = '0';
    
    // Remove from document flow after fade animation (0.6s)
    setTimeout(() => {
        preloader.style.display = 'none';
    }, 600);
});

// 2. SCROLL EVENTS (STICKY NAV & SCROLL SPY)
const navbar = document.getElementById('navbar');
const sections = document.querySelectorAll('section, header');
const navLinks = document.querySelectorAll('.nav-links a');

window.addEventListener('scroll', () => {
    
    // A. Sticky Navigation Effect
    // Adds 'scrolled' class when page is scrolled down more than 50px
    if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }

    // B. Scroll Spy (Active Menu Highlighting)
    let currentSection = '';

    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.clientHeight;
        
        // Offset of 150px to handle the fixed header height
        if (window.scrollY >= (sectionTop - 150)) {
            currentSection = section.getAttribute('id');
        }
    });

    navLinks.forEach(link => {
        link.classList.remove('active');
        // Check if the link href contains the current section ID
        if (link.getAttribute('href').includes(currentSection)) {
            link.classList.add('active');
        }
    });
});

// 3. SCROLL REVEAL ANIMATION
// Triggers the CSS '.visible' class when elements enter the viewport
const observerOptions = {
    threshold: 0.15, // Trigger when 15% of the element is visible
    rootMargin: "0px 0px -50px 0px" // Slightly offset the trigger point
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            // Optional: Stop observing once revealed (for one-time animation)
            // observer.unobserve(entry.target); 
        }
    });
}, observerOptions);

// Target all elements with the class 'fade-up'
document.querySelectorAll('.fade-up').forEach((el) => {
    observer.observe(el);
});
